import java.util.Scanner;
/**
 * Write a description of class RPSGame here.
 * 
 * @author Dylan Cruz
 * @version 1.0
 */
public class RPSGame
{
    // instance variables - replace the example below with your own
    private int mySelection;
    private int computerWins;
    private int humanWins;
    private int ties;
    private int plays;
    
    /**
     * Constructor for objects of class RPSGame
     */
    public RPSGame()
    {
        plays = 0;
        ties = 0;
        humanWins = 0;
        computerWins = 0;
        mySelection = 0;
    }

    /**
     * Resets game stats.
     */
    public void reset()
    {
        plays = 0;
        ties = 0;
        humanWins = 0;
        computerWins = 0;
    }

    /**
     * Returns the number of times the computer has won.
     */
    public int getComputerWins()
    {
        return computerWins;
    }

    /**
     * Returns the number of times the inferior human has won.
     */
    public int getHumanWins()
    {
        return humanWins;
    }

    public int getTies()
    {
        return ties;
    }

    /**
     * humanTakesTurn - this method will give a menu for the user:
     *  Choose:
     *      (1) rock
     *      (2) paper
     *      (3) scissors
     *      (4) reset game
     *  Please enter 1, 2, 3 or 4:
     *  
     *  this method uses the scanner class to allow the user to input something
     */
    public int humanTakesTurn()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to Rock Paper Scissors: The Game");
        System.out.println("Please Choose:");
        System.out.println("(1) The Rockin' Rock");
        System.out.println("(2) The Powerful Paper");
        System.out.println("(3) The Sharp Scissors");
        System.out.println("(4) Reset");
        mySelection = scan.nextInt();
        while(mySelection < 1 || mySelection > 4)
        {
            System.out.println("Please choose a valid number.");
            scan.nextInt();
        }
        if(mySelection == 1)
            return 1;
        if(mySelection == 2)
            return 2;
        if(mySelection == 3)
            return 3;
        if(mySelection == 4)
            reset(); 
        return 0;
    }

    /**
     * play game - input parameters
     * @param :     h = human choice ( 1 = rock, 2 = paper, 3 = scissors)
     * 
     * This method will instantiate a computer object and invoke the computerTakesTurnMethod
     * then check if human or computer won or is it a tie -- keep track of game stats
     */
    public void play(int h)
    {
        h = mySelection;
        randomHelper rand = new randomHelper();
        int c = rand.computerTakesTurn();
        
        if(h==1 && c==3)
            humanWins++;
        if(h==1 && c==2)
            computerWins++;
        if(h==1 && c==1)
            ties++;
        
        if(h==2 && c==3)
            computerWins++;
        if(h==2 && c==2)
            ties++;
        if(h==2 && c==1)
            humanWins++;
        
        if(h==3 && c==3)
            ties++;
        if(h==3 && c==2)
            humanWins++;
        if(h==3 && c==1)
            computerWins++;
             
    }

    
    
    /**
     * getOveralGameStatus
     * @param - outputs string reflecting how the human did against the computer.
     */
    public String getOveralGameStatus()
    {
        String status;
        int stat = humanWins - computerWins;
        if(stat >= 5)
            status = "You're the new king of Rock Paper Scissor: The Game. Congratulations.";
        else if(stat >=1 && stat <= 4)
            status = "You're on the way to become the best. Keep it up.";
        else if(stat == 0)
            status = "You're even with the computer, you can do this!";
        else if(
    }
}
        
