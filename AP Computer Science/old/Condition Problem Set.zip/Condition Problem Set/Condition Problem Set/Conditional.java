import java.text.DecimalFormat;
/**
 * Conditional - Yeahhhhh Buddyyyyy
 * 
 * @author Dylan Cruz
 * @version 1.0 (10/14/11)
 */
public class Conditional
{
    
    public Conditional()
    {

    }
    
    /**
     * Method that outputs in decimal format.
     */
    public void outputDec(double num)
    {
        DecimalFormat twoDecimal = new DecimalFormat("0.00");
        
        System.out.println(twoDecimal.format(num));
    }

    /**
     * Take a numeric grade and outputs an alpha grade... like a boss.
     */
    public void alphaGradeFinder(int numGrade)
    {
        if(numGrade < 0 || numGrade>100)    //error check, leggo
            System.out.println("Please enter a valid number");
        else //now time for the real magic
            if(numGrade >= 90)
                System.out.println("A");
                else
                if(numGrade >= 80)
                    System.out.println("B");
                    else
                    if(numGrade >= 70)
                        System.out.println("C");
                        else
                        if(numGrade >= 65)
                            System.out.println("D");
                            else
                            if(numGrade < 65)
                                System.out.println("You failed.");
    }

    /**
     * This method takes a letter grade such as A, and converts it into quality points, which in this case would be 4.0
     */
    public void qualityPoints(String letterGrade)
    {
            
            if(letterGrade.equalsIgnoreCase("A"))
                System.out.println("4.0");
                else
                if(letterGrade.equalsIgnoreCase("B+"))
                    System.out.println("3.5");
                    else
                    if(letterGrade.equalsIgnoreCase("B"))
                        System.out.println("3.0");
                        else
                        if(letterGrade.equalsIgnoreCase("C+"))
                            System.out.println("2.5");
                            else
                            if(letterGrade.equalsIgnoreCase("C"))
                                System.out.println("2.0");
                                else
                                if(letterGrade.equalsIgnoreCase("D+"))
                                    System.out.println("1.5");
                                    else
                                    if(letterGrade.equalsIgnoreCase("D"))
                                        System.out.println("1.0");
                                        else
                                            System.out.println("You Fail");
            
    }
    
    /**
     * This method takes the absolute value of any given number.
     */
    public void absVal(double num)
    {
            if(num > 0)
                System.out.println("The absoltue vale of " + num + " is " + num);
                else
                if(num < 0)
                    System.out.println("The absoltue vale of " + num + " is " + -num);
            
        
        
    }

    /**
     * This method finds out whether or not a year is a leap year or not.
     */
    public void leapYear(int year)
    {
        if(year%400==0)
            System.out.println("That year is definately a leap year.");
            else
            if(year%100==0)
                System.out.println("That year is definately NOT a leap year.");
                else
                if(year%4==0)
                    System.out.println("That year is a leap year.");
                    else
                    System.out.println("That year is NOT a leap year.");
    
    }

    /**
     * This method finds out what type of triangle you have, after entering its sides.
     */
    public void triangleType(int side1, int side2, int side3)
    {
        if(side1 < 0 || side2 < 0 || side3 < 0)
            System.out.println("Please enter valid numbers.");
            else{
        if(side1!=side2 && side2!=side3 && side1!=side3)
            System.out.println("This triangle is scalene.");
            else
            if(side1==side2 && side2==side3 && side1==side3)
                System.out.println("This triangle is equilateral.");
                else
                    System.out.println("This triangle is isoceles.");
                }
    }

    /**
     * This method finds out which date Easter will be on any given year between 1984 and 2048.
     */
    public void easterFinder(int y)
    {
        int a = y % 19;
        int b = y % 4;
        int c = y % 7;
        int d = (19 * a + 24) % 30;
        int e = (2 * b + 4 * c + 6 * d + 5) % 7;
        int marchDate = 22 + d + e;
        
        if(y > 2048 || y < 1982)
            System.out.println("Please enter a year between 1982 and 2048");
        
        if(marchDate > 31)
            System.out.println("Easter in " + y + " fell on the date April " + (marchDate - 31));
            else
            System.out.println("Easter in " + y + " fell on the date March " + marchDate);
    }

    /**
     * Method that creates a payroll based on pay per hour and hours worked.
     */
    public void payroll(double payHour, double hoursWorked)
    {
        if(payHour < 0 || hoursWorked < 0)
            System.out.println("Please enter valid numbers.");
            else{
        DecimalFormat twoDecimal = new DecimalFormat("0.00");
        
        double regularPay;
        double overtime;
        double overtimeHours;
        double grossPay;
        double federalTax;
        double stateTax;
        double fica;
        double netPay;
        
        if(hoursWorked > 40)
            overtime = (hoursWorked - 40) * (1.5 * payHour);
            else
            overtime = 0;
        overtimeHours = hoursWorked - 40;
        regularPay = payHour * (hoursWorked - overtimeHours);
        grossPay = regularPay + overtime;
        federalTax = grossPay * .20;
        stateTax = grossPay * .06;
        fica = grossPay * .05;
        netPay = grossPay - federalTax - stateTax - fica;
        
        System.out.println("Payroll");
        System.out.println("********************");
        System.out.println("Regular Pay: \t$" + twoDecimal.format(regularPay));
        System.out.println("Over Time: \t$" + twoDecimal.format(overtime));
        System.out.println("Gross Pay: \t$" + twoDecimal.format(grossPay));
        System.out.println("Federal Tax: \t$" + twoDecimal.format(federalTax));
        System.out.println("State Tax: \t$" + twoDecimal.format(stateTax));
        System.out.println("FICA: \t\t$" + twoDecimal.format(fica));
        System.out.println("********************");
        System.out.println("Net Pay: \t$" + twoDecimal.format(netPay));
        System.out.println("********************");
    }
    }
    
    /**
     * This method checks to see how much money your energy bill will be.
     */
    public void power(double kWh)
    {
        DecimalFormat twoDecimal = new DecimalFormat("0.00");
        double l1Cost = .0577;
        double l2Cost = .0532;
        double l3Cost = .0511;
        double l1Total;
        double l2Total;
        double l3Total;
        double total;
        
        if(kWh < 0)
            System.out.println("Please enter a valid number.");
        else
        if(kWh <= 1000){
            l1Total = kWh * l1Cost;
            total = l1Total;
            System.out.println("Level 1" + "(" + kWh + ")" + "\t$" + twoDecimal.format(l1Total));
            System.out.println("Level 2" + "(0)" + "\t$0.00");
            System.out.println("Level 3" + "(0)" + "\t$0.00");
            System.out.println("Total Due: " + "\t$" + twoDecimal.format(total));
        }
        else
            if(kWh > 1000 && kWh <=4000){
                l1Total = 1000 * l1Cost;
                l2Total = (kWh - 1000) * l2Cost;
                total = l1Total + l2Total;
                System.out.println("Level 1" + "(1000)" + "\t$" + twoDecimal.format(l1Total));
                System.out.println("Level 2" + "(" + (kWh - 1000) + ")" + "\t$" + twoDecimal.format(l2Total));
                System.out.println("Level 3" + "(0)" + "\t$0.00");
                System.out.println("Total Due: " + "\t$" + twoDecimal.format(total));
        }
            else
                if(kWh > 5000){
                    l1Total = 1000 * l1Cost;
                    l2Total = 4000 * l2Cost;
                    l3Total = (kWh - 5000) * l3Cost;
                    total = l1Total + l2Total + l3Total;
                    System.out.println("Level 1" + "(1000)" + "\t$" + twoDecimal.format(l1Total));
                    System.out.println("Level 2" + "(4000)" + "\t$" + twoDecimal.format(l2Total));
                    System.out.println("Level 3" + "(" + (kWh - 4000) + ")" + "\t$" + twoDecimal.format(l3Total));
                    System.out.println("Total Due: " + "\t$" + twoDecimal.format(total));
        }
        }

        /**
         * This method checks to see how much your income tax is.
         */
        public void incomeTax(double salary)
        {
        DecimalFormat twoDecimal = new DecimalFormat("0.00");
        double rate1 = 0.03;
        double rate2 = 0.055;
        double rate3 = 0.108;
        double rate4 = 0.237;
        
        if(salary < 0)
            System.out.println("Please enter valid numbers.");
            else
            if(salary >= 0 && salary <= 10000){
                double tax = salary * rate1;
                System.out.println("Your income tax on $" + salary + " is " + "$" + twoDecimal.format(tax));
    }
                else
                if(salary >= 10001 && salary <= 20000){
                    double tax = salary * rate2;
                    System.out.println("Your income tax on $" + salary + " is " + "$" + twoDecimal.format(tax));
    }
                    else
                    if(salary >= 20001 && salary <= 40000){
                        double tax = salary * rate3;
                        System.out.println("Your income tax on $" + salary + " is " + "$" + twoDecimal.format(tax));
    }
                        else
                        if(salary >= 40001){
                        double tax = salary * rate4;
                        System.out.println("Your income tax on $" + salary + " is " + "$" + twoDecimal.format(tax));
    }
    }

    /**
     * This method returns a....
     */
    public void numberWord(int num)
    {
        if(num < 20 || num > 59)
            System.out.println("Please enter a number between 20 and 59.");
            else
            if((num / 10) == 2)
                System.out.print("Twenty ");
                else
            if((num / 10) == 3)
                System.out.print("Thirty ");
                else
            if((num / 10) == 4)
                System.out.print("Fourty ");
                else
            if((num / 10) == 5)
                System.out.print("Fifty ");
                else
                System.out.print("You did something wrong :( ");
                
        if(num % 10 == 1)
            System.out.print("One");
            else
            if(num % 10 == 2)
            System.out.print("Two");
            else
            if(num % 10 == 3)
            System.out.print("Three");
            else
            if(num % 10 == 4)
            System.out.print("Four");
            else
            if(num % 10 == 5)
            System.out.print("Five");
            else
            if(num % 10 == 6)
            System.out.print("Six");
            else
            if(num % 10 == 7)
            System.out.print("Seven");
            else
            if(num % 10 == 8)
            System.out.print("Eight");
            else
            if(num % 10 == 9)
            System.out.print("Nine");
            else
                System.out.print("You did something wrong :( ");
    }
}