
/**
 * Problem Set 1 - #1
 * 
 * Age Class
 * 
 * Calculate the approximate age of a person.
 * 
 * @author Dylan Cruz
 * @version 1.0 (9/23/11)
 */
public class age
{

    /**
     * Calculate age given a year
     * 
     * @param  year   input parameter
     */
    public void calcAge(int year)
    {
        // put your code here
        
        int age;
        
        System.out.println('\f');
        age = 2011 - year;
        System.out.println("Your age is approximately " + age);
        
    }
}
