
/**
 * Get day, month & year.
 * 
 * @author Dylan Cruz
 * @version 1.0 (11/18/11)
 */
public class Date
{
    private int mth, dy, yr;

    public Date()
    {
     mth = 0;
     dy = 0;
     yr = 0;
    }

    public Date(int day, int month, int year)
    {
        dy = day;
        mth = month;
        yr = year;
    }

    public int getDay()
    {
        return dy;
    }
    
    public int getMonth()
    {
        return mth;
    }
    
    public int getYear()
    {
        return yr;
    }
    
    public String getMonthName()
    {
        String str = new String();
        
        if(mth == 1)
            return("January");
        if(mth == 2)
            return("February");
        if(mth == 3)
            return("March");
        if(mth == 4)
            return("April");
        if(mth == 5)
            return("May");
        if(mth == 6)
            return("June");
        if(mth == 7)
            return("July");
        if(mth == 8)
            return("August");
        if(mth == 9)
            return("September");
        if(mth == 10)
            return("October");
        if(mth == 11)
            return("November");
        if(mth == 12)
            return("December");
        return "You put a non-existent month in.";
    }

    public void setYear(int newYear)
    {
        yr = newYear;
    }    

    public void setEqual(int newMonth, int newDay, int newYear)
    {
        mth = newMonth;
        dy = newDay;
        yr = newYear;
    }
    
    public boolean equals(Date otherDate)
    {
        if(
    }
    
}
